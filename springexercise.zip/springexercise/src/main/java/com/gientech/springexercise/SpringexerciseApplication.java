package com.gientech.springexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringexerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringexerciseApplication.class, args);
	}

}
