package com.gientech.springexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringexerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
